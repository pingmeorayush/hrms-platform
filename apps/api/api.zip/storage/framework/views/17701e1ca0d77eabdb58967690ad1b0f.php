<?php echo e($slot); ?>

<?php /**PATH /Users/ayushchauhan/Documents/phoenix-hrms-boilerplate/apps/api/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>